package com.sangamone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebEnquiryFormApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebEnquiryFormApplication.class, args);
	}

}
